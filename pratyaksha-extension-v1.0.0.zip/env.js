// PRATYAKSHA Environment Configuration
// This file is auto-read by the extension service worker & side panel cockpit.

export const ENV = {
  PROVIDER: "mistral", // "mistral" | "gemini" | "openrouter" | "deterministic"
  MISTRAL_API_KEY: "ElIVQInF2Bt6pIZYfrBF97H6wZr9c8wg",
  MISTRAL_MODEL: "codestral-latest",
  GEMINI_API_KEY: "AQ.Ab8RN6Kb8ymEYre5L5t3DKP6RXkEb3V_59U5vguT2YBlZbda5Q",
  GEMINI_MODEL: "gemini-3.5-flash",
  OPENROUTER_API_KEY: "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",
  OPENROUTER_MODEL: "deepseek/deepseek-v4.1-flash"
};

/**
 * Returns effective provider, API keys, and models with fallback hierarchy:
 * 1. chrome.storage.local
 * 2. Static ENV
 * 3. Runtime fetch of .env file
 */
export async function getEffectiveConfig() {
  let stored = {};
  try {
    stored = await chrome.storage.local.get([
      'provider',
      'mistralApiKey',
      'mistralModel',
      'geminiApiKey',
      'geminiModel',
      'openrouterApiKey',
      'openrouterModel',
      'engineMode'
    ]);
  } catch (e) {
    console.warn('[PRATYAKSHA] Could not query chrome.storage:', e);
  }

  // Parse .env if available
  let envFile = {};
  try {
    const envUrl = chrome.runtime.getURL('.env');
    const res = await fetch(envUrl);
    if (res.ok) {
      const text = await res.text();
      const lines = text.split('\n');
      for (const line of lines) {
        const match = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*)$/);
        if (match) {
          const k = match[1].trim();
          const v = match[2].trim().replace(/^['"]|['"]$/g, '');
          envFile[k] = v;
        }
      }
    }
  } catch (e) {}

  const mistralApiKey = stored.mistralApiKey || envFile.MISTRAL_API_KEY || ENV.MISTRAL_API_KEY || '';
  const mistralModel = stored.mistralModel || envFile.MISTRAL_MODEL || ENV.MISTRAL_MODEL || 'codestral-latest';

  let geminiModel = stored.geminiModel || envFile.GEMINI_MODEL || ENV.GEMINI_MODEL || 'gemini-3.5-flash';
  const geminiApiKey = stored.geminiApiKey || envFile.GEMINI_API_KEY || ENV.GEMINI_API_KEY || '';

  const openrouterApiKey = stored.openrouterApiKey || envFile.OPENROUTER_API_KEY || ENV.OPENROUTER_API_KEY || '';
  const openrouterModel = stored.openrouterModel || envFile.OPENROUTER_MODEL || ENV.OPENROUTER_MODEL || 'deepseek/deepseek-v4.1-flash';

  // Active provider
  let provider = stored.provider;
  if (!provider) {
    if (mistralApiKey) {
      provider = 'mistral';
    } else if (openrouterApiKey) {
      provider = 'openrouter';
    } else if (geminiApiKey) {
      provider = 'gemini';
    } else {
      provider = 'deterministic';
    }
  }

  let activeApiKey = '';
  let activeModel = '';
  if (provider === 'mistral') {
    activeApiKey = mistralApiKey;
    activeModel = mistralModel;
  } else if (provider === 'openrouter') {
    activeApiKey = openrouterApiKey;
    activeModel = openrouterModel;
  } else if (provider === 'gemini') {
    activeApiKey = geminiApiKey;
    activeModel = geminiModel;
  }

  return {
    provider,
    apiKey: activeApiKey,
    model: activeModel,
    mistralApiKey,
    mistralModel,
    geminiApiKey,
    geminiModel,
    openrouterApiKey,
    openrouterModel,
    engineMode: provider
  };
}
